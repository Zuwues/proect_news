@extends('layouts.app')

@section('content')
<h1 >В разработке</h1>
@endsection

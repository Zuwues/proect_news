<?php $__env->startSection('content'); ?>
    <h1>Welcome</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\33 группа\HELP\example-app\resources\views/welcome.blade.php ENDPATH**/ ?>